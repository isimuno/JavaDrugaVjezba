package main.hr.java.covidportal.model;

public interface Zarazno {

    void prelazakZarazeNaOsobu(Osoba osoba);
}
